import './App.css'

function App() {

  return (
    <>
      <div className='bg-pink-500'>Amit Sharma</div>
    </>
  )
}

export default App
