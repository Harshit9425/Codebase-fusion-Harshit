// This file provides environment variables for the client
window.ENV = {
  VITE_MEDIASOUP_SERVER_URL: "http://localhost:3031",
  VITE_IDE_SERVER_URL: "http://localhost:3021"
}; 